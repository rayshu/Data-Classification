// Business Area Dropdown
var dropdown = document.getElementById('businessArea');
if(dropdown) {
    var businessAreaNames = ['CB CDIO',
                    'CTO - Core Banking',
                    'CTO - CP, HS, SD & OR, Security',
                    'CTO - Enterprise Engineering ',
                    'CTO  - FRALH',
                    'Data & Analytics',
                    'NWM CDIO',
                    'P&BM',
                    'Payments',
                    'PB Digitech'
                ]

    for(var i=0,l=businessAreaNames.length; i<l; i++) {
        var businessAreaName = businessAreaNames[i];

        var option = document.createElement('option');
        option.setAttribute('value',businessAreaName);

        var optionText = document.createTextNode(businessAreaName);
        option.appendChild(optionText);

        dropdown.appendChild(option);
    }
}

// Department Dropdown


// Location  Dropdown
var dropdown3 = document.getElementById('location');
if(dropdown) {
    var locationNames = ['Edinburgh','Manchester','London','Gurugram','Chennai','Bengaluru','Mumbai','Other']

    for(var i=0,l=locationNames.length; i<l; i++) {
        var locationName = locationNames[i];

        var option = document.createElement('option');
        option.setAttribute('value',locationName);

        var optionText = document.createTextNode(locationName);
        option.appendChild(optionText);

        dropdown3.appendChild(option);
    }
}

function downloadCSV(csv, filename) {
    var csvFile;
    var downloadLink;

    csvFile = new Blob([csv], {type: "text/csv"});

    // Download link
    downloadLink = document.createElement("a");

    // File name
    downloadLink.download = filename;

    // Create a link to the file
    downloadLink.href = window.URL.createObjectURL(csvFile);

    // Hide download link
    downloadLink.style.display = "none";

    // Add the link to DOM
    document.body.appendChild(downloadLink);

    // Click download link
    downloadLink.click();
}


function exportTableToCSV(filename, classname) {
    var csv = [];
    var rows = document.querySelectorAll("table."+classname+" tr");

    for (var i = 0; i < rows.length; i++) {
        var row = [],
        cols = rows[i].querySelectorAll("td:not(.action), th:not(.action)");

        for (var j = 0; j < cols.length; j++)
            row.push(cols[j].innerText);

        csv.push(row.join(","));
    }
    // Download CSV file
    downloadCSV(csv.join("\n"), filename);
}
