 
CREATE USER 'oreilly_user'@'localhost' IDENTIFIED BY 'test123';

GRANT ALL PRIVILEGES ON *.* TO 'oreilly_user'@'localhost';

ALTER USER 'oreilly_user'@'localhost' IDENTIFIED WITH mysql_native_password BY 'test123';
 

CREATE DATABASE `licence_management`;

use `licence_management`;

drop table if exists `users`;

create table `users`(
	`username` varchar(50) not null,
	`password` varchar(50) not null,
	`enabled` tinyint(1) not null,
	primary key (`username`)
) ENGINE = InnoDB default charset = latin1;

insert into `users` values ('user1','{noop}test123',1);

drop table if exists `authorities`;

create table `authorities`(
	`username` varchar(50) not null,
	`authority` varchar(50) not null,
	unique key `authorities_idx_1` (`username`,`authority`),
	constraint `authorites_ibfk_1` foreign key (`username`) references `users` (`username`)
)  ENGINE = InnoDB default charset = latin1;

insert into `authorities` values ('user1','ROLE_ADMIN');

drop table if exists `user_request`;
 
CREATE TABLE `user_request` (
		`user_request_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `employee_first_name` VARCHAR(64) NOT NULL,
        `employee_last_name` VARCHAR(64) NOT NULL,
        `employee_email_id` VARCHAR(256) NOT NULL,
        `is_rejected` BOOLEAN NOT NULL DEFAULT FALSE,
        `is_approved` BOOLEAN NOT NULL DEFAULT FALSE,
        `is_pending`  BOOLEAN NOT NULL DEFAULT TRUE,
        `request_datetime` DATETIME  NULL DEFAULT CURRENT_TIMESTAMP,
        `business_area` VARCHAR(256) NOT NULL,
        `department` VARCHAR(256) NOT NULL,
        `racf_id` VARCHAR(7) NOT NULL,
        `employee_code` VARCHAR(7) NOT NULL,
        `contact_number` VARCHAR(10) NOT NULL,
        `location` VARCHAR(256) NOT NULL,
        `request_reason` TEXT NULL,
        `extend_reason` TEXT NULL,
        `available_licence_id` INT(11) UNSIGNED NOT NULL,
        PRIMARY KEY (`user_request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

drop table if exists `approved_user`;

CREATE TABLE `approved_user` (
		`approved_user_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_request_id` INT(11) UNSIGNED NOT NULL,
        `start_date` DATE NOT NULL,
        `end_date` DATE NOT NULL,
        PRIMARY KEY (`approved_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

drop table if exists `available_licences`;

CREATE TABLE `available_licences` (
		`available_licence_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `licence_name` VARCHAR(128) NOT NULL,
        `licence_count` INT UNSIGNED NOT NULL,
        `request_submission_msg` TEXT NULL,
        `request_approved_msg` TEXT NULL,
        `request_deleted_msg` TEXT NULL,
        `request_rejected_msg` TEXT NULL,
        `request_cron_msg` TEXT NULL,
        `request_extend_msg` TEXT NULL,
        PRIMARY KEY (`available_licence_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

drop table if exists `deleted_request`;

CREATE TABLE `deleted_request` (
		`delete_request_id` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
        `employee_first_name` VARCHAR(64) NOT NULL,
        `employee_last_name` VARCHAR(64) NOT NULL,
        `employee_email_id` VARCHAR(256) NOT NULL,
        `business_area` VARCHAR(256) NOT NULL,
        `department` VARCHAR(256) NOT NULL,
        `racf_id` VARCHAR(7) NOT NULL,
        `employee_code` VARCHAR(7) NOT NULL,
        `contact_number` VARCHAR(10) NOT NULL,
        `location` VARCHAR(256) NOT NULL,
        `licence_name` VARCHAR(128) NOT NULL,
		`start_date` DATE NOT NULL,
        `end_date` DATE NOT NULL,
        `is_expired` boolean not null default false,
        PRIMARY KEY (`delete_request_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

ALTER TABLE `approved_user` ADD INDEX(`user_request_id`);
ALTER TABLE `approved_user` ADD FOREIGN KEY (`user_request_id`) REFERENCES `user_request`(`user_request_id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `user_request` ADD INDEX(`available_licence_id`);
ALTER TABLE `user_request` ADD FOREIGN KEY (`available_licence_id`) REFERENCES `available_licences`(`available_licence_id`) ON DELETE CASCADE ON UPDATE CASCADE;

insert into `available_licences` (`licence_name`,`licence_count`) VALUES
("OReilly",500);

update available_licences set request_submission_msg = "Thank you for showing interest.

Your request for 3 months O’Reilly License is in queue.

You will get notification by O’Reilly (reply@et.oreilly.com) about the access in 5 working days from now.

Happy Learning!

Regards,
Technology Academy";

update available_licences set request_approved_msg = "Congratulations!
Your request for 3 months O’Reilly Licence access request has been approved.

Create your login credentials and explore learning resources offered by Oreilly by following the link as below: https://www.oreilly.com/sign-in.html


For any query write to us on Technology.Academy@rbs.co.uk

Happy Learning!

Regards,
Technology Academy";


update available_licences set request_deleted_msg = "Your 3 months O’Reilly Licence has expired now.

Hope you had a wonderful learning experience with O’Reilly.
Please share your learning experience with Oreilly by following this link. (TBD)

To explore and to avail learning resources further on O’Reilly you can raise a new request by following below link:
http://11.15.50.105:8080/


Happy Learning!


Regards,
Technology Academy";


update available_licences set request_rejected_msg = "Thank you for showing interest.

Your request for O’Reilly License access has been rejected.

(Reason TBD)

For any further query write to us as Technlogy.Academy@rbs.co.uk

Regards,
Technology Academy";

update available_licences set request_cron_msg = "Gentle reminder!
Your 3 months O’Reilly License access will expire in 10 days from now.

Complete your pending learning and make the best use of available resources offered by O’Reilly.

Happy Learning!

Regards,
Technology Academy";

update available_licences set request_extend_msg = "Congratulations!

Your extension request for 3 months O’Reilly Licence access request has been approved.

For any query write to us on Technology.Academy@rbs.co.uk

Happy Learning!

Regards,
Technology Academy
";

SET FOREIGN_KEY_CHECKS = 1;