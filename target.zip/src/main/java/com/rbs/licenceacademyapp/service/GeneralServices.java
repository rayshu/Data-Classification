package com.rbs.licenceacademyapp.service;

import com.rbs.licenceacademyapp.models.ApprovedUser;
import com.rbs.licenceacademyapp.models.AvailableLicences;
import com.rbs.licenceacademyapp.models.DeletedRequest;
import com.rbs.licenceacademyapp.models.UserRequest;
import com.rbs.licenceacademyapp.repository.ApprovedUserRepository;
import com.rbs.licenceacademyapp.repository.AvailableLicenceRepository;
import com.rbs.licenceacademyapp.repository.DeletedRequestRepository;
import com.rbs.licenceacademyapp.repository.UserRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GeneralServices {

    @Autowired
    private UserRequestRepository userRequestRepository;

    @Autowired
    private AvailableLicenceRepository availableLicenceRepository;

    @Autowired
    private ApprovedUserRepository approvedUserRepository;

    @Autowired
    private DeletedRequestRepository deletedRequestRepository;

    public void saveUserRequest(UserRequest userRequest) {
        userRequestRepository.save(userRequest);
    }

    public void saveAvailableLicence(AvailableLicences availableLicences) {
        availableLicenceRepository.save(availableLicences);
    }

    public void saveApprovedUser(ApprovedUser approvedUser) {
        approvedUserRepository.save(approvedUser);
    }

    public List<AvailableLicences> getLicences(){
        return availableLicenceRepository.findAll();
    }

    public AvailableLicences findLicenceById(int licenceId){
        Optional<AvailableLicences> result = availableLicenceRepository.findById(licenceId);

        AvailableLicences availableLicence = null;

        if (result.isPresent()) {
            availableLicence = result.get();
        }
        else {
            // we didn't find the Licence
            throw new RuntimeException("Did not find Licence id - " + licenceId);
        }

        return availableLicence;
    }

    public UserRequest findRequestById(int requestId){
        Optional<UserRequest> result = userRequestRepository.findById(requestId);

        UserRequest userRequest = null;

        if (result.isPresent()) {
            userRequest = result.get();
        }
        else {
            // we didn't find the Licence
            throw new RuntimeException("Did not find Request id - " + requestId);
        }
        return userRequest;
    }

    public ApprovedUser findApprovedUserById(int approvedUserId){
        Optional<ApprovedUser> result = approvedUserRepository.findById(approvedUserId);

        ApprovedUser approvedUser = null;

        if (result.isPresent()) {
            approvedUser = result.get();
        }
        else {
            // we didn't find the Licence
            throw new RuntimeException("Did not find Request id - " + approvedUserId);
        }
        return approvedUser;
    }


    public void deleteRequestById(int id) {
        userRequestRepository.deleteById(id);
    }


    public UserRequest checkRequest(String emailId, int availableLicenceId) {
        Optional<UserRequest> result = Optional.ofNullable(userRequestRepository.findByEmailAndLicenceId(emailId, availableLicenceId));

        UserRequest userRequest = null;

        if (result.isPresent()) {
            userRequest = result.get();
        }
        return userRequest;
    }


    public void saveDeleteRequest(DeletedRequest deletedRequest) {
        deletedRequestRepository.save(deletedRequest);
    }

}
