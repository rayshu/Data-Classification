package com.rbs.licenceacademyapp.service;

import java.util.Date;
import java.util.List;

import com.rbs.licenceacademyapp.models.DeletedRequest;
import com.rbs.licenceacademyapp.repository.DeletedRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbs.licenceacademyapp.models.ApprovedUser;
import com.rbs.licenceacademyapp.models.UserRequest;
import com.rbs.licenceacademyapp.repository.ApprovedUserRepository;
import com.rbs.licenceacademyapp.repository.UserRequestRepository;

@Service
public class AdminServices {

    @Autowired
    private UserRequestRepository userRequestRepository;

    @Autowired
    private ApprovedUserRepository approvedUserRepository;

    @Autowired
    private DeletedRequestRepository deletedRequestRepository;

    public List<UserRequest> getPendingRequests()
    {
        return userRequestRepository.findAllPendingRequest();
    }
    public List<UserRequest> getRejectedRequests()
    {
        return userRequestRepository.findAllRejectedRequest();
    }
    public List<ApprovedUser> getApprovedRequests() {
        return approvedUserRepository.findAllByOrderByEndDateDesc();
    }

    public List<ApprovedUser> getApprovedRequestsByEndDate(Date date) {
        return approvedUserRepository.findByEndDate(date);
    }

    public List<DeletedRequest> getRequestsByExpiryStatus(boolean value) {
        return deletedRequestRepository.findRequestByExpiryStatus(value);
    }
}
