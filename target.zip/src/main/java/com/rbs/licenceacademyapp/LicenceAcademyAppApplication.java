package com.rbs.licenceacademyapp;

import com.rbs.licenceacademyapp.utils.EmailUtility;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class LicenceAcademyAppApplication {

	@Bean
	public EmailUtility getEmailUtility()
	{
		return new EmailUtility();
	}

	public static void main(String[] args) {
		SpringApplication.run(LicenceAcademyAppApplication.class, args);
	}

}
