package com.rbs.licenceacademyapp.models;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "deleted_request")
public class DeletedRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "delete_request_id")
    private int deleteRequestId;

    @Column(name = "employee_email_id")
    private String email;

    @Column(name = "employee_first_name")
    private String firstName;

    @Column(name = "employee_last_name")
    private String lastName;

    @Column(name = "business_area")
    private String businessArea;

    @Column(name = "employee_code")
    private String employeeCode;

    @Column(name = "location")
    private String location;

    @Column(name = "licence_name")
    private String licenceName;

    @Column(name="start_date")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name="end_date")
    @Temporal(TemporalType.DATE)
    private Date endDate;

    @Column(name="is_expired")
    private boolean isExpired;

    public DeletedRequest() {
    }

    public DeletedRequest(String email, String firstName, String lastName, String businessArea, String employeeCode, String location, String licenceName, Date startDate, Date endDate, boolean isExpired) {
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.businessArea = businessArea;
        this.employeeCode = employeeCode;
        this.location = location;
        this.licenceName = licenceName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.isExpired = isExpired;
    }

    public int getDeleteRequestId() {
        return deleteRequestId;
    }

    public void setDeleteRequestId(int deleteRequestId) {
        this.deleteRequestId = deleteRequestId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getBusinessArea() {
        return businessArea;
    }

    public void setBusinessArea(String businessArea) {
        this.businessArea = businessArea;
    }

    public String getEmployeeCode() {
        return employeeCode;
    }

    public void setEmployeeCode(String employeeCode) {
        this.employeeCode = employeeCode;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getLicenceName() {
        return licenceName;
    }

    public void setLicenceName(String licenceName) {
        this.licenceName = licenceName;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public boolean isExpired() {
        return isExpired;
    }

    public void setExpired(boolean isExpired) {
        this.isExpired = isExpired;
    }
}
