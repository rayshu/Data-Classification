package com.rbs.licenceacademyapp.models;

import java.util.Date;

import javax.persistence.*;

import com.rbs.licenceacademyapp.utils.DateUtils;

@Entity
@Table(name="user_request")
public class UserRequest {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_request_id")
	private int requestId;

	@Column(name = "employee_email_id")
	private String email;

	@Column(name = "employee_first_name")
	private String firstName;

	@Column(name = "employee_last_name")
	private String lastName;

	@Column(name = "is_pending")
	private boolean isPending;

	@Column(name = "is_approved")
	private boolean isApproved;

	@Column(name = "is_rejected")
	private boolean isRejected;

	@Column(name = "request_datetime")
	@Temporal(TemporalType.TIMESTAMP)
	private Date requestDate;

	@Column(name = "business_area")
	private String businessArea;

	@Column(name = "employee_code")
	private String employeeCode;

	@Column(name = "location")
	private String location;

	@Column(name = "request_reason")
	private String requestReason;

	@Column(name = "extend_reason")
	private String extendReason;


	@ManyToOne
	@JoinColumn(name = "available_licence_id")
	private AvailableLicences availableLicences = new AvailableLicences();

	public AvailableLicences getAvailableLicences() {
		return availableLicences;
	}

	public void setAvailableLicences(AvailableLicences availableLicences) {
		this.availableLicences = availableLicences;
	}

	public UserRequest(){
	}

	public UserRequest(String email, String firstName, String lastName, String businessArea, String employeeCode, String location, String requestReason, String extendReason) {
		this.email = email;
		this.firstName = firstName;
		this.lastName = lastName;
		this.businessArea = businessArea;
		this.employeeCode = employeeCode;
		this.location = location;
		this.requestReason = requestReason;
		this.extendReason = extendReason;
	}


	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int requestId) {
		this.requestId = requestId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public boolean isPending() {
		return isPending;
	}

	public void setPending(boolean pending) {
		isPending = pending;
	}

	public boolean isApproved() {
		return isApproved;
	}

	public void setApproved(boolean approved) {
		isApproved = approved;
	}

	public boolean isRejected() {
		return isRejected;
	}

	public void setRejected(boolean rejected) {
		isRejected = rejected;
	}

	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public String getBusinessArea() {
		return businessArea;
	}

	public void setBusinessArea(String businessArea) {
		this.businessArea = businessArea;
	}


	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getRequestReason() {
		return requestReason;
	}

	public void setRequestReason(String requestReason) {
		this.requestReason = requestReason;
	}

	public String getExtendReason() {
		return extendReason;
	}

	public void setExtendReason(String extendReason) {
		this.extendReason = extendReason;
	}

	@Override
	public String toString() {
		return "UserRequest{" +
				"requestId=" + requestId +
				", email='" + email + '\'' +
				", firstName='" + firstName + '\'' +
				", lastName='" + lastName + '\'' +
				", isPending=" + isPending +
				", isApproved=" + isApproved +
				", isRejected=" + isRejected +
				", requestDate=" + DateUtils.dateTimeToString(requestDate) +
				", businessArea='" + businessArea + '\'' +
				", employeeCode='" + employeeCode + '\'' +
				", location='" + location + '\'' +
				", requestReason='" + requestReason + '\'' +
				", extendReason='" + extendReason + '\'' +
				'}';
	}
}