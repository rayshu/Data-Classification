package com.rbs.licenceacademyapp.models;

import javax.persistence.*;

@Entity
@Table(name="available_licences")
public class AvailableLicences
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "available_licence_id")
	private int licenceId;

	@Column(name="licence_name")
	private String licenceName;

	@Column(name="licence_count")
	private int licenceCount;

	@Column(name="request_submission_msg")
	private String requestSubmissionMsg;

	@Column(name="request_approved_msg")
	private String requestApprovedMsg;

	@Column(name="request_deleted_msg")
	private String requestDeletedMsg;

	@Column(name="request_rejected_msg")
	private String requestRejectedMsg;

	@Column(name="request_cron_msg")
	private String requestCronMsg;

	@Column(name = "request_extend_msg")
	private String requestExtendMsg;

	public String getRequestExtendMsg() {
		return requestExtendMsg;
	}

	public void setRequestExtendMsg(String requestExtendMsg) {
		this.requestExtendMsg = requestExtendMsg;
	}

	public AvailableLicences() {
	}

	public AvailableLicences(String licenceName, int licenceCount) {
		this.licenceName = licenceName;
		this.licenceCount = licenceCount;
	}

	public int getLicenceId() {
		return licenceId;
	}

	public void setLicenceId(int licenceId) {
		this.licenceId = licenceId;
	}

	public String getLicenceName() {
		return licenceName;
	}

	public void setLicenceName(String licenceName) {
		this.licenceName = licenceName;
	}

	public int getLicenceCount() {
		return licenceCount;
	}

	public void setLicenceCount(int licenceCount) {
		this.licenceCount = licenceCount;
	}

	public String getRequestSubmissionMsg() {
		return requestSubmissionMsg;
	}

	public void setRequestSubmissionMsg(String requestSubmissionMsg) {
		this.requestSubmissionMsg = requestSubmissionMsg;
	}

	public String getRequestApprovedMsg() {
		return requestApprovedMsg;
	}

	public void setRequestApprovedMsg(String requestApprovedMsg) {
		this.requestApprovedMsg = requestApprovedMsg;
	}

	public String getRequestDeletedMsg() {
		return requestDeletedMsg;
	}

	public void setRequestDeletedMsg(String requestDeletedMsg) {
		this.requestDeletedMsg = requestDeletedMsg;
	}

	public String getRequestRejectedMsg() {
		return requestRejectedMsg;
	}

	public void setRequestRejectedMsg(String requestRejectedMsg) {
		this.requestRejectedMsg = requestRejectedMsg;
	}

	public String getRequestCronMsg() {
		return requestCronMsg;
	}

	public void setRequestCronMsg(String requestCronMsg) {
		this.requestCronMsg = requestCronMsg;
	}
}
