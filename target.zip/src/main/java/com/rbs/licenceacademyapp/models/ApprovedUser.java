package com.rbs.licenceacademyapp.models;

import com.rbs.licenceacademyapp.utils.DateUtils;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="approved_user")
public class ApprovedUser {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    @Column(name = "approved_user_id")
    private int approvedUserId;

    @Column(name="start_date")
    @Temporal(TemporalType.DATE)
    private Date startDate;

    @Column(name="end_date")
    @Temporal(TemporalType.DATE)
    private Date endDate;


    @OneToOne
    @JoinColumn(name="user_request_id")
    private UserRequest userRequest;

    public UserRequest getUserRequest() {
        return userRequest;
    }

    public void setUserRequest(UserRequest userRequest) {
        this.userRequest = userRequest;
    }

    public ApprovedUser(){
    }

    public ApprovedUser(Date startDate, Date endDate) {
        this.startDate = startDate;
        this.endDate = endDate;
    }


    public int getApprovedUserId() {
        return approvedUserId;
    }

    public void setApprovedUserId(int approvedUserId) {
        this.approvedUserId = approvedUserId;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }


    @Override
    public String toString() {
        return "ApprovedUser{" +
                "approvedUserId='" + approvedUserId + '\'' +
                ", startDate=" + DateUtils.dateToString(startDate) +
                ", endDate=" + DateUtils.dateToString(endDate) +
                '}';
    }
}
