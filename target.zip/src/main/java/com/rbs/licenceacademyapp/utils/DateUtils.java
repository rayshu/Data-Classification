package com.rbs.licenceacademyapp.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class DateUtils {
	private static SimpleDateFormat formatterDatetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	private static SimpleDateFormat formatterDate = new SimpleDateFormat("yyyy-MM-dd");
	
	public static Date parseDate(String strDate) throws ParseException {
		return formatterDate.parse(strDate);
	}

	public static String dateToString(Date theDate) {
		if (theDate!=null) {
			return formatterDate.format(theDate);
		}
		return null;
	}

	public static Date parseDateTime(String strDate) throws ParseException {
		return formatterDatetime.parse(strDate);
	}

	public static String dateTimeToString(Date theDate) {
		if (theDate!=null) {
			return formatterDatetime.format(theDate);
		}
		return null;
	}

	public static String getCurrentTimeStamp(){
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		return now.format(formatter);
	}

	public static String getCurrentDate(){
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return now.format(formatter);
	}

	public static Date addMonth(Date date, int i) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.MONTH, i);
		return cal.getTime();
	}

	public static Date addDays(Date date, int i) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, i);
		return cal.getTime();
	}
}
