package com.rbs.licenceacademyapp.utils;

public class EmailAttributes 
{
	private String messageBody;
	private String messageSubject;
	private String recipientEmail;

	public EmailAttributes() {
	}

	public EmailAttributes(String messageBody, String messageSubject, String recipientEmail) {
		this.messageBody = messageBody;
		this.messageSubject = messageSubject;
		this.recipientEmail = recipientEmail;
	}

	public String getMessageBody() {
		return messageBody;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	public String getMessageSubject() {
		return messageSubject;
	}

	public void setMessageSubject(String messageSubject) {
		this.messageSubject = messageSubject;
	}

	public String getRecipientEmail() {
		return recipientEmail;
	}

	public void setRecipientEmail(String recipientEmail) {
		this.recipientEmail = recipientEmail;
	}
}
