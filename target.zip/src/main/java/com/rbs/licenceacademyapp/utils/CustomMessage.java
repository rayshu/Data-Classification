package com.rbs.licenceacademyapp.utils;

public class CustomMessage {
    private String status;
    private String message;
    private String backUrl;

    public CustomMessage(String status, String message) {
        this.status = status;
        this.message = message;
    }

    public CustomMessage(){
        this.status = "Nothing to Display";
        this.backUrl = "/";
        this.message ="Please navigate back using the button below!";
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getBackUrl() {
        return backUrl;
    }

    public void setBackUrl(String backUrl) {
        this.backUrl = backUrl;
    }
}
