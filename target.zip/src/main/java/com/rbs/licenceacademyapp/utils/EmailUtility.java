package com.rbs.licenceacademyapp.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;


public class EmailUtility {

	@Autowired
    private JavaMailSender javaMailSender;
	
	@Value("${spring.mail.username}")
	private String senderAdd;

    public String getSenderAdd() {
        return senderAdd;
    }


    public void sendEmail(EmailAttributes emailAttr) {

        SimpleMailMessage msg = new SimpleMailMessage();

        msg.setTo(emailAttr.getRecipientEmail());
        msg.setFrom(senderAdd);
        msg.setSubject(emailAttr.getMessageSubject());
        msg.setText(emailAttr.getMessageBody());

        javaMailSender.send(msg);

    }
}
