package com.rbs.licenceacademyapp.controller;

import com.rbs.licenceacademyapp.models.AvailableLicences;
import com.rbs.licenceacademyapp.models.UserRequest;
import com.rbs.licenceacademyapp.service.GeneralServices;
import com.rbs.licenceacademyapp.utils.CustomMessage;
import com.rbs.licenceacademyapp.utils.DateUtils;
import com.rbs.licenceacademyapp.utils.EmailAttributes;
import com.rbs.licenceacademyapp.utils.EmailUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.text.ParseException;
import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private GeneralServices generalServices;

    @Autowired
    private EmailUtility emailUtility;



    @GetMapping("/")
    public String welcomePage(Model model){
        return "welcome_view";
    }

    @GetMapping("/request-licence")
    public String requestLicencePage(Model model){

        List<AvailableLicences> availableLicences = generalServices.getLicences();

        UserRequest userRequest = new UserRequest();

        model.addAttribute("licenceRequest", userRequest);
        model.addAttribute("licences",availableLicences);

        return "request_licence";
    }


    @PostMapping("/save-request")
    public String saveLicenceRequest(@ModelAttribute("licenceRequest") UserRequest userRequest, RedirectAttributes redirectAttributes) throws ParseException {

        /*1. user should not be able to create a duplicate request
             -> do not allow the request if it is in pending state or in approved state
             -> for a particular RACF + licence id allow the request if it is rejected*/
        CustomMessage customMessage = new CustomMessage();
        EmailAttributes emailAttributes = new EmailAttributes();
        String emailId = userRequest.getEmail();
        int availableLicenceId = userRequest.getAvailableLicences().getLicenceId();

        UserRequest tempRequest = generalServices.checkRequest(emailId,availableLicenceId);

        if(tempRequest != null){  //there is one record
            if(tempRequest.isApproved() || tempRequest.isPending()){
                customMessage.setStatus("Error");
                customMessage.setMessage("Your request is either pending or already approved. Please do not create the duplicate requests!");
                customMessage.setBackUrl("/");
                redirectAttributes.addFlashAttribute("CustomMessage",customMessage);
                return "redirect:/request-feedback"; // do not allow the request
            }
        }

        /*2. upon request submission we should prompt the user correct response
            -> if the licences are available then academy will connect within in 48 hours
            -> if the licences are not available then your request is in wait list*/


        userRequest.setPending(true);
        userRequest.setRequestDate(DateUtils.parseDateTime(DateUtils.getCurrentTimeStamp()));
        generalServices.saveUserRequest(userRequest);

        AvailableLicences availableLicences = generalServices.findLicenceById(availableLicenceId);
        int availableLicenceCount = availableLicences.getLicenceCount();


        //send the mail to user
        emailAttributes.setMessageBody(availableLicences.getRequestSubmissionMsg());
        emailAttributes.setMessageSubject("Notification - " + availableLicences.getLicenceName() + " License");
        emailAttributes.setRecipientEmail(userRequest.getEmail());
        emailUtility.sendEmail(emailAttributes);

        //send the mail to academy
        emailAttributes.setMessageBody("There is a new access request for " + availableLicences.getLicenceName() + " Licence.\r\n\r\nPlease review and action.\r\n\r\nRegards,\r\nTechnology Academy\r\n");
        emailAttributes.setMessageSubject("Notification - " + availableLicences.getLicenceName() + " License");
        emailAttributes.setRecipientEmail(emailUtility.getSenderAdd());
        emailUtility.sendEmail(emailAttributes);

        if(availableLicenceCount == 0){
            customMessage.setStatus("Pending");
            customMessage.setMessage("Right Now, No licences are available. But we have logged your request. We will connect with you once we get some more licences!");
            customMessage.setBackUrl("/");
            redirectAttributes.addFlashAttribute("CustomMessage",customMessage);

            return "redirect:/request-feedback";
        }

        customMessage.setStatus("Success");
        customMessage.setMessage("Your request is submitted successfully. Academy will contact you within 24 hours!");
        customMessage.setBackUrl("/");
        redirectAttributes.addFlashAttribute("CustomMessage",customMessage);

        return "redirect:/request-feedback";
    }

    @GetMapping("/request-feedback")
    public String UserRequestFeedback(){
        return "request_feedback";
    }

    //add mapping for request form
    @GetMapping("/extend-licence")
    public String extendLicencePage(Model model){

        List<AvailableLicences> availableLicences = generalServices.getLicences();

        UserRequest userRequest = new UserRequest();

        model.addAttribute("licenceRequest", userRequest);
        model.addAttribute("licences",availableLicences);

        return "extend_licence";
    }

    //add post method for form submission
    @PostMapping("/save-extend-request")
    public String saveExtendRequest(@ModelAttribute("licenceRequest") UserRequest userRequest, RedirectAttributes redirectAttributes) {

        CustomMessage customMessage = new CustomMessage();
        EmailAttributes emailAttributes = new EmailAttributes();

        UserRequest request = generalServices.checkRequest(userRequest.getEmail(), userRequest.getAvailableLicences().getLicenceId());
		System.out.println(request);
        if(request != null && request.isApproved()) {
            //set extend reason
            request.setExtendReason(userRequest.getExtendReason());
            generalServices.saveUserRequest(request);

            //send email to tech academy (No need to send email to user)
            emailAttributes.setMessageBody("Hi\r\n"+"There is a pending extension request.\r\n\r\n"+"Please action and close.\r\n\r\n\r\nName : " + request.getFirstName() + " " + request.getLastName() + "\r\nEmail : " + request.getEmail()+"\r\n\r\n\r\nRegards,\r\nTechnology Academy\r\n");
            emailAttributes.setMessageSubject("Notification - " + request.getAvailableLicences().getLicenceName()
                    + " License");
            emailAttributes.setRecipientEmail(emailUtility.getSenderAdd());
            emailUtility.sendEmail(emailAttributes);

            customMessage.setStatus("Success");
            customMessage.setMessage("Your request for licence extension has been submitted successfully. Academy will contact you within 24 hours!");
            customMessage.setBackUrl("/");
            redirectAttributes.addFlashAttribute("CustomMessage",customMessage);
            return "redirect:/request-feedback";
        }
        else {
            customMessage.setStatus("Error");
            customMessage.setMessage("Extension request denied - \n"
            		+ "Since you dont have an O'Rielly license at present therefore your extension request has \nbeen denied. To get a new Licence access follow the instructions as below: \n"
            		+"1. Click on the “Request Licence” button.\n"
            		+"2. Fill and submit the form with the required information\n"
            		+"3. Follow the email notification in your inbox");
            customMessage.setBackUrl("/");

            redirectAttributes.addFlashAttribute("CustomMessage",customMessage);
            return "redirect:/request-feedback";
        }
    }

}
