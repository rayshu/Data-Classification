package com.rbs.licenceacademyapp.controller;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.rbs.licenceacademyapp.models.AvailableLicences;
import com.rbs.licenceacademyapp.models.DeletedRequest;
import com.rbs.licenceacademyapp.utils.CustomMessage;
import com.rbs.licenceacademyapp.utils.DateUtils;
import com.rbs.licenceacademyapp.utils.EmailAttributes;
import com.rbs.licenceacademyapp.utils.EmailUtility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.rbs.licenceacademyapp.models.ApprovedUser;
import com.rbs.licenceacademyapp.models.UserRequest;
import com.rbs.licenceacademyapp.service.AdminServices;
import com.rbs.licenceacademyapp.service.GeneralServices;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminServices adminServices;

    @Autowired
    private GeneralServices generalServices;


    @Autowired
    private EmailUtility emailUtility;


    @GetMapping("/dashboard")
    public String adminDashboardPage(Model model){

        List<UserRequest> pendingRequests = adminServices.getPendingRequests();
        List<ApprovedUser> approvedUsers = adminServices.getApprovedRequests();
        List<UserRequest> rejectedUsers = adminServices.getRejectedRequests();
        List<AvailableLicences> availableLicences = generalServices.getLicences();
        List<DeletedRequest> deletedRequests = adminServices.getRequestsByExpiryStatus(false);
        List<DeletedRequest> expiredRequests = adminServices.getRequestsByExpiryStatus(true);

        model.addAttribute("pendingRequests",pendingRequests);
        model.addAttribute("approvedRequests",approvedUsers);
        model.addAttribute("rejectedRequests",rejectedUsers);
        model.addAttribute("availableLicences",availableLicences);
        model.addAttribute("deletedRequests",deletedRequests);
        model.addAttribute("expiredRequests",expiredRequests);

        return "admin_dashboard";
    }

    @GetMapping("/approveUserRequest")
    public String approveRequest(@RequestParam("requestId") int requestId, RedirectAttributes redirectAttributes) throws ParseException {
        CustomMessage customMessage = new CustomMessage();
        EmailAttributes emailAttributes = new EmailAttributes();
        UserRequest request = generalServices.findRequestById(requestId);
        AvailableLicences availableLicences = generalServices.findLicenceById(request.getAvailableLicences().getLicenceId());

        if(availableLicences.getLicenceCount() > 0){
            availableLicences.setLicenceCount(availableLicences.getLicenceCount() - 1);
            generalServices.saveAvailableLicence(availableLicences);
        }
        else{
            customMessage.setStatus("Error");
            customMessage.setMessage("You Cannot allocate more licence. As the licence count for " + availableLicences.getLicenceName() + " is already zero!");
            customMessage.setBackUrl("/admin/dashboard");

            redirectAttributes.addFlashAttribute("CustomMessage",customMessage);
            return "redirect:/admin/request-feedback";
        }

        request.setPending(false);
        request.setApproved(true);
        generalServices.saveUserRequest(request);


        ApprovedUser approvedUser = new ApprovedUser();
        approvedUser.setStartDate(DateUtils.parseDate(DateUtils.getCurrentDate()));
        approvedUser.setEndDate(DateUtils.addMonth(DateUtils.parseDate(DateUtils.getCurrentDate()),3));
        approvedUser.setUserRequest(request);
        generalServices.saveApprovedUser(approvedUser);

        emailAttributes.setMessageBody(availableLicences.getRequestApprovedMsg());
        emailAttributes.setMessageSubject("Notification - " + availableLicences.getLicenceName() + " License");
        emailAttributes.setRecipientEmail(request.getEmail());
        emailUtility.sendEmail(emailAttributes);

        return "redirect:/admin/dashboard";
    }

    @GetMapping("/processRejectRequest")
    public String rejectRequest(@RequestParam("message-text") String messageText, @RequestParam("request-id") int requestId) {

        EmailAttributes emailAttributes = new EmailAttributes();
        UserRequest request = generalServices.findRequestById(requestId);
        AvailableLicences availableLicences = generalServices.findLicenceById(request.getAvailableLicences().getLicenceId());
        request.setPending(false);
        request.setRejected(true);
        generalServices.saveUserRequest(request);

        String mailMessage = availableLicences.getRequestRejectedMsg();
        mailMessage = mailMessage.replaceFirst("Reason TBD",messageText);

        emailAttributes.setMessageBody(mailMessage);
        emailAttributes.setMessageSubject("Notification - " + availableLicences.getLicenceName() + " License");
        emailAttributes.setRecipientEmail(request.getEmail());
        emailUtility.sendEmail(emailAttributes);

        return "redirect:/admin/dashboard";
    }

    @GetMapping("/deleteRequest")
    public String deleteRequest(@RequestParam("approvedUserId") int approvedUserId, RedirectAttributes redirectAttributes) throws ParseException {

        EmailAttributes emailAttributes = new EmailAttributes();
        ApprovedUser approvedUser = generalServices.findApprovedUserById(approvedUserId);

        /*if(approvedUser.getEndDate().compareTo(DateUtils.parseDate(DateUtils.getCurrentDate()))  > 0){
            customMessage.setStatus("Error");
            customMessage.setMessage("Request cannot be delete before the end date!");
            customMessage.setBackUrl("/admin/dashboard");
            redirectAttributes.addFlashAttribute("CustomMessage",customMessage);

            return "redirect:/admin/request-feedback";
        }*/

        AvailableLicences availableLicences = generalServices.findLicenceById(approvedUser.getUserRequest().getAvailableLicences().getLicenceId());
        availableLicences.setLicenceCount(availableLicences.getLicenceCount() + 1);

        //Save the Request in Delete Table for future usages
        DeletedRequest deletedRequest = new DeletedRequest(
                approvedUser.getUserRequest().getEmail(),
                approvedUser.getUserRequest().getFirstName(),
                approvedUser.getUserRequest().getLastName(),
                approvedUser.getUserRequest().getBusinessArea(),
                approvedUser.getUserRequest().getEmployeeCode(),                
                approvedUser.getUserRequest().getLocation(),
                approvedUser.getUserRequest().getAvailableLicences().getLicenceName(),
                approvedUser.getStartDate(),
                approvedUser.getEndDate(),
                false
        );

        generalServices.saveDeleteRequest(deletedRequest);
        generalServices.saveAvailableLicence(availableLicences);
        generalServices.deleteRequestById(approvedUser.getUserRequest().getRequestId());

        emailAttributes.setMessageBody(availableLicences.getRequestDeletedMsg());
        emailAttributes.setMessageSubject("Notification - " + availableLicences.getLicenceName() + " License");
        emailAttributes.setRecipientEmail(approvedUser.getUserRequest().getEmail());
        emailUtility.sendEmail(emailAttributes);

        return "redirect:/admin/dashboard";
    }

    @GetMapping("/request-feedback")
    public String UserRequestFeedback(){
        return "request_feedback";
    }

    @GetMapping("/processExtendRequest")
    public String extendRequest(@RequestParam("approvedUserId") int approvedUserId) throws ParseException {

        EmailAttributes emailAttributes = new EmailAttributes();
        //get approvedUser object
        ApprovedUser approvedUser = generalServices.findApprovedUserById(approvedUserId);
        //get availableLicences object
        AvailableLicences availableLicences = approvedUser.getUserRequest().getAvailableLicences();
        //update the end date.
        approvedUser.setEndDate(DateUtils.addMonth(approvedUser.getEndDate(), 3));
        //save to db
        generalServices.saveApprovedUser(approvedUser);
        //send mail
        emailAttributes.setMessageBody(availableLicences.getRequestExtendMsg());
        emailAttributes.setMessageSubject("Notification - " + availableLicences.getLicenceName() + " License");
        emailAttributes.setRecipientEmail(approvedUser.getUserRequest().getEmail());
        emailUtility.sendEmail(emailAttributes);

        return "redirect:/admin/dashboard";
    }

    @Scheduled(cron="0 0 9 ? * *",zone = "IST")
    public void cronJob_expiryWarning() throws ParseException {

        EmailAttributes emailAttributes = new EmailAttributes();
        //add current date + 10 days
        Date date = DateUtils.addDays(DateUtils.parseDate(DateUtils.getCurrentDate()), 10);

        //get approved users whose end date is equal to current date + 10 days
        List<ApprovedUser> approvedUsers = adminServices.getApprovedRequestsByEndDate(date);

        if(!approvedUsers.isEmpty()) {
            for(ApprovedUser user:approvedUsers) {
                    emailAttributes.setMessageBody(user.getUserRequest().getAvailableLicences().getRequestCronMsg());
                    emailAttributes.setMessageSubject("Notification - " + user.getUserRequest().getAvailableLicences().getLicenceName() + " License");
                    emailAttributes.setRecipientEmail(user.getUserRequest().getEmail());
                    emailUtility.sendEmail(emailAttributes);
            }
        }
    }

    @Scheduled(cron="0 0 8 ? * *",zone = "IST")
    public void cronJob_autoDeleted() throws ParseException {

        EmailAttributes emailAttributes = new EmailAttributes();
        Date date = DateUtils.parseDate(DateUtils.getCurrentDate());

        List<ApprovedUser> approvedUsers = adminServices.getApprovedRequestsByEndDate(date);

        //for message generation
        int count = 1;
        String messageBody = "The licences registered to the following email addresses will get expired today -\r\n";

        if(!approvedUsers.isEmpty()) {
            for(ApprovedUser user : approvedUsers) {
                AvailableLicences availableLicences = generalServices.findLicenceById(user.getUserRequest().getAvailableLicences().getLicenceId());
                availableLicences.setLicenceCount(availableLicences.getLicenceCount() + 1);

                //Save the Request in Delete Table for future usages
                DeletedRequest deletedRequest = new DeletedRequest(
                        user.getUserRequest().getEmail(),
                        user.getUserRequest().getFirstName(),
                        user.getUserRequest().getLastName(),
                        user.getUserRequest().getBusinessArea(),
                        user.getUserRequest().getEmployeeCode(),
                        user.getUserRequest().getLocation(),
                        user.getUserRequest().getAvailableLicences().getLicenceName(),
                        user.getStartDate(),
                        user.getEndDate(),
                        true
                );

                generalServices.saveDeleteRequest(deletedRequest);
                generalServices.saveAvailableLicence(availableLicences);
                generalServices.deleteRequestById(user.getUserRequest().getRequestId());

                emailAttributes.setMessageBody(availableLicences.getRequestDeletedMsg());
                emailAttributes.setMessageSubject("Notification - " + availableLicences.getLicenceName() + " License");
                emailAttributes.setRecipientEmail(user.getUserRequest().getEmail());
                emailUtility.sendEmail(emailAttributes);

                messageBody +=  "\r\n" + count +". ";
                messageBody += user.getUserRequest().getEmail();
                count += 1;
            }

            messageBody +=  "\r\n" + "\r\nThanks and Regards\r\nTechnology Academy";

            emailAttributes.setMessageBody(messageBody);
            emailAttributes.setMessageSubject("Notification - License Expiry");
            emailAttributes.setRecipientEmail(emailUtility.getSenderAdd());
            emailUtility.sendEmail(emailAttributes);
        }
    }

}
