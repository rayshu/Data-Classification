package com.rbs.licenceacademyapp.repository;

import com.rbs.licenceacademyapp.models.UserRequest;
import org.apache.catalina.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRequestRepository extends JpaRepository<UserRequest, Integer> {

    @Query("select ur from UserRequest ur where ur.isPending = true order by ur.requestDate desc")
    public List<UserRequest> findAllPendingRequest();

    @Query("select ur from UserRequest ur where ur.isRejected = true order by ur.requestDate desc")
    public List<UserRequest> findAllRejectedRequest();

    @Query("select ur from UserRequest ur where ur.email = :email AND ur.availableLicences.licenceId = :availableLicenceId")
    public UserRequest findByEmailAndLicenceId(@Param("email") String email, @Param("availableLicenceId") int licenceId);
}
