package com.rbs.licenceacademyapp.repository;

import com.rbs.licenceacademyapp.models.ApprovedUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface ApprovedUserRepository extends JpaRepository<ApprovedUser, Integer> {
    public List<ApprovedUser> findAllByOrderByEndDateDesc();

    @Query("select au from ApprovedUser au where au.endDate = :enddate")
    public List<ApprovedUser> findByEndDate(@Param("enddate") Date date);

}
