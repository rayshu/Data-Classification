package com.rbs.licenceacademyapp.repository;

import com.rbs.licenceacademyapp.models.DeletedRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DeletedRequestRepository extends JpaRepository<DeletedRequest,Integer> {
    public List<DeletedRequest> findAllByOrderByEndDateDesc();

    @Query("select du from DeletedRequest du where du.isExpired = :value order by du.endDate desc")
    public List<DeletedRequest> findRequestByExpiryStatus(@Param("value") boolean value );
}
