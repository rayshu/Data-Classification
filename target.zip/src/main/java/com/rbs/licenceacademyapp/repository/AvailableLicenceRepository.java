package com.rbs.licenceacademyapp.repository;

import com.rbs.licenceacademyapp.models.AvailableLicences;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AvailableLicenceRepository extends JpaRepository<AvailableLicences, Integer> {
}
