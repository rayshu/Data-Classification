package com.rbs.licenceacademyapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LicenceAcademyAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
